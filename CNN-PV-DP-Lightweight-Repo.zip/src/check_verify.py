import os

path = "C:/Users/tharu/OneDrive/Desktop/Solar_panel_project"

print("Folders:", os.listdir(path))

for folder in os.listdir(path):
    folder_path = os.path.join(path, folder)
    
    if os.path.isdir(folder_path):   # ✅ this avoids crash
        print(folder, "->", len(os.listdir(folder_path)))