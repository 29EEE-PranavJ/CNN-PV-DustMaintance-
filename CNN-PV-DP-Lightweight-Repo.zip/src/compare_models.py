# FINAL SOLAR PANEL DUST DETECTION USING MOBILENET

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, GlobalAveragePooling2D
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

from sklearn.metrics import classification_report, confusion_matrix

# -------------------------
# FOCAL LOSS (HANDLE DUST CLASS BETTER)
# -------------------------

def focal_loss(gamma=2., alpha=0.25):
    def loss(y_true, y_pred):
        y_true = tf.cast(y_true, tf.float32)
        bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
        p_t = y_true * y_pred + (1 - y_true) * (1 - y_pred)
        return alpha * tf.pow((1 - p_t), gamma) * bce
    return loss

# -------------------------
# DATASET PATH
# -------------------------

train_dir = "C:/Users/tharu/OneDrive/Desktop/Solar_panel_project/Detect_solar_dust"

IMG_HEIGHT = 224
IMG_WIDTH = 224
BATCH_SIZE = 32

# -------------------------
# DATA AUGMENTATION
# -------------------------

datagen = ImageDataGenerator(
    preprocessing_function=preprocess_input,
    validation_split=0.2,
    rotation_range=30,
    zoom_range=0.3,
    shear_range=0.2,
    horizontal_flip=True,
    brightness_range=[0.8,1.2]
)

train_gen = datagen.flow_from_directory(
    train_dir,
    target_size=(IMG_HEIGHT, IMG_WIDTH),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='training'
)

val_gen = datagen.flow_from_directory(
    train_dir,
    target_size=(IMG_HEIGHT, IMG_WIDTH),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='validation'
)

print("Class indices:", train_gen.class_indices)

# -------------------------
# LOAD MOBILENET
# -------------------------

base_model = MobileNetV2(
    input_shape=(IMG_HEIGHT, IMG_WIDTH, 3),
    include_top=False,
    weights='imagenet'
)

# -------------------------
# FINE-TUNING
# -------------------------

base_model.trainable = True

for layer in base_model.layers[:-10]:
    layer.trainable = False

# -------------------------
# BUILD MODEL
# -------------------------

model = Sequential([
    base_model,
    GlobalAveragePooling2D(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(1, activation='sigmoid')
])

# -------------------------
# COMPILE MODEL
# -------------------------

model.compile(
    optimizer=Adam(learning_rate=0.00001),
    loss=focal_loss(),
    metrics=['accuracy']
)

model.summary()

# -------------------------
# CALLBACKS
# -------------------------

early_stop = EarlyStopping(
    monitor='val_loss',
    patience=3,
    restore_best_weights=True
)

lr_reduce = ReduceLROnPlateau(
    monitor='val_loss',
    factor=0.3,
    patience=2,
    min_lr=1e-6
)

# -------------------------
# CLASS WEIGHT (LIGHT BALANCE)
# -------------------------

class_weight = {0:1, 1:1.3}

# -------------------------
# TRAIN MODEL
# -------------------------

history = model.fit(
    train_gen,
    validation_data=val_gen,
    epochs=15,
    class_weight=class_weight,
    callbacks=[early_stop, lr_reduce]
)

# -------------------------
# EVALUATION
# -------------------------

val_gen.reset()

preds = model.predict(val_gen)
true_labels = val_gen.classes

# 🔥 THRESHOLD TUNING
pred_labels = (preds > 0.35).astype(int).reshape(-1)

accuracy = np.mean(pred_labels == true_labels)
print("\nFinal Accuracy:", accuracy)

# -------------------------
# CLASSIFICATION REPORT
# -------------------------

print(classification_report(true_labels, pred_labels))

# -------------------------
# CONFUSION MATRIX
# -------------------------

cm = confusion_matrix(true_labels, pred_labels)

plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title("Final MobileNet Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# -------------------------
# SAVE MODEL
# -------------------------

model.save("final_mobilenet_model.h5")