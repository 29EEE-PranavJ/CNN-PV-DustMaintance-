from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np

# Load trained model
model = load_model("solar_panel_dust_cnn.h5")

# Image size used during training
IMG_HEIGHT = 128
IMG_WIDTH = 128

# Load test image
img_path = "test6.jpg"

img = image.load_img(img_path, target_size=(IMG_HEIGHT, IMG_WIDTH))

img_array = image.img_to_array(img)

img_array = img_array / 255.0

img_array = np.expand_dims(img_array, axis=0)

# Predict
prediction = model.predict(img_array)

if prediction[0][0] > 0.5:
    print("Prediction: Dusty panel → Maintenance required")
else:
    print("Prediction: Clean panel → No maintenance required")