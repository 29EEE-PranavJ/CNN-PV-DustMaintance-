# Solar Panel Dust Detection CNN (Local Version)

import os
import random
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

from sklearn.metrics import classification_report, confusion_matrix

# -------------------------
# DATASET PATH (LOCAL)
# -------------------------

train_dir = "Detect_solar_dust"

classes = ['Clean', 'Dusty']

# -------------------------
# IMAGE PARAMETERS
# -------------------------

IMG_HEIGHT = 128
IMG_WIDTH = 128
BATCH_SIZE = 32

# -------------------------
# DATA AUGMENTATION
# -------------------------

train_datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2,
    rotation_range=20,
    zoom_range=0.2,
    horizontal_flip=True
)

# -------------------------
# LOAD TRAINING DATA
# -------------------------

train_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(IMG_HEIGHT, IMG_WIDTH),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='training',
    shuffle=True
)

# -------------------------
# LOAD VALIDATION DATA
# -------------------------

val_generator = train_datagen.flow_from_directory(
    train_dir,
    target_size=(IMG_HEIGHT, IMG_WIDTH),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='validation',
    shuffle=False
)

print("Class indices:", train_generator.class_indices)

# -------------------------
# BUILD CNN MODEL
# -------------------------

model = Sequential([

    Conv2D(32, (3,3), activation='relu', input_shape=(IMG_HEIGHT, IMG_WIDTH,3)),
    MaxPooling2D(2,2),

    Conv2D(64, (3,3), activation='relu'),
    MaxPooling2D(2,2),

    Conv2D(128, (3,3), activation='relu'),
    MaxPooling2D(2,2),

    Flatten(),

    Dense(128, activation='relu'),

    Dropout(0.5),

    Dense(1, activation='sigmoid')

])

model.summary()

# -------------------------
# COMPILE MODEL
# -------------------------

model.compile(
    optimizer=Adam(learning_rate=0.0001),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# -------------------------
# EARLY STOPPING
# -------------------------

early_stop = EarlyStopping(
    monitor='val_loss',
    patience=3,
    restore_best_weights=True
)

# -------------------------
# TRAIN MODEL
# -------------------------

history = model.fit(
    train_generator,
    validation_data=val_generator,
    epochs=20,
    callbacks=[early_stop]
)

# -------------------------
# SAVE MODEL
# -------------------------

model.save("solar_panel_dust_cnn.h5")

# -------------------------
# PLOT TRAINING RESULTS
# -------------------------

plt.figure(figsize=(12,5))

plt.subplot(1,2,1)
plt.plot(history.history['accuracy'], label='train_accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.title("Accuracy")
plt.legend()

plt.subplot(1,2,2)
plt.plot(history.history['loss'], label='train_loss')
plt.plot(history.history['val_loss'], label='val_loss')
plt.title("Loss")
plt.legend()

plt.show()

# -------------------------
# MODEL EVALUATION
# -------------------------

val_generator.reset()

preds = model.predict(val_generator)

pred_labels = (preds > 0.5).astype(int).reshape(-1)

true_labels = val_generator.classes

accuracy = np.mean(pred_labels == true_labels)

print("Validation Accuracy:", accuracy)

# -------------------------
# CLASSIFICATION REPORT
# -------------------------

print(classification_report(true_labels, pred_labels, target_names=classes))

# -------------------------
# CONFUSION MATRIX
# -------------------------

cm = confusion_matrix(true_labels, pred_labels)

plt.figure(figsize=(6,5))

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    xticklabels=classes,
    yticklabels=classes,
    cmap='Blues'
)

plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.title("Confusion Matrix")

plt.show()

# -------------------------
# TEST WITH RANDOM IMAGES
# -------------------------

test_images = []
test_labels = []

for cls in classes:

    cls_dir = os.path.join(train_dir, cls)

    images = [img for img in os.listdir(cls_dir) if img.lower().endswith(('.jpg','.jpeg','.png'))]

    sample_imgs = random.sample(images, 5)

    for img_name in sample_imgs:

        img_path = os.path.join(cls_dir, img_name)

        img = image.load_img(img_path, target_size=(IMG_HEIGHT, IMG_WIDTH))

        img_array = image.img_to_array(img) / 255.0

        test_images.append(img_array)

        test_labels.append(cls)

test_images = np.array(test_images)

predictions = model.predict(test_images)

pred_labels = ['Dusty' if p>0.5 else 'Clean' for p in predictions]

# -------------------------
# SHOW PREDICTIONS
# -------------------------

plt.figure(figsize=(20,5))

for i in range(10):

    plt.subplot(2,5,i+1)

    plt.imshow(test_images[i])

    plt.title(f"Actual: {test_labels[i]}\nPredicted: {pred_labels[i]}")

    plt.axis('off')

plt.show()