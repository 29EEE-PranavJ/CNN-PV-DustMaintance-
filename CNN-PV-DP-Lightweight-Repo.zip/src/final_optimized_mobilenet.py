# FINAL OPTIMIZED MOBILENET (Stable + High Accuracy)

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, GlobalAveragePooling2D
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

from sklearn.metrics import classification_report, confusion_matrix

# -------------------------
# DATASET PATH
# -------------------------

train_dir = "C:/Users/tharu/OneDrive/Desktop/Solar_panel_project/Detect_solar_dust"

# -------------------------
# IMAGE SIZE (IMPORTANT CHANGE)
# -------------------------

IMG_HEIGHT = 224
IMG_WIDTH = 224
BATCH_SIZE = 32

# -------------------------
# DATA AUGMENTATION
# -------------------------

datagen = ImageDataGenerator(
    preprocessing_function=preprocess_input,
    validation_split=0.2,
    rotation_range=30,
    zoom_range=0.3,
    shear_range=0.2,
    horizontal_flip=True,
    brightness_range=[0.8,1.2]
)

train_gen = datagen.flow_from_directory(
    train_dir,
    target_size=(IMG_HEIGHT, IMG_WIDTH),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='training'
)

val_gen = datagen.flow_from_directory(
    train_dir,
    target_size=(IMG_HEIGHT, IMG_WIDTH),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='validation'
)

print("Class indices:", train_gen.class_indices)

# -------------------------
# MOBILENET BASE
# -------------------------

base_model = MobileNetV2(
    input_shape=(IMG_HEIGHT, IMG_WIDTH, 3),
    include_top=False,
    weights='imagenet'
)

# -------------------------
# FINE-TUNING (IMPORTANT)
# -------------------------

base_model.trainable = True

for layer in base_model.layers[:-10]:
    layer.trainable = False

# -------------------------
# FINAL MODEL
# -------------------------

model = Sequential([
    base_model,
    GlobalAveragePooling2D(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(1, activation='sigmoid')
])

# -------------------------
# COMPILE
# -------------------------

model.compile(
    optimizer=Adam(learning_rate=0.00001),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

model.summary()

# -------------------------
# CALLBACKS
# -------------------------

early_stop = EarlyStopping(
    monitor='val_loss',
    patience=3,
    restore_best_weights=True
)

lr_reduce = ReduceLROnPlateau(
    monitor='val_loss',
    factor=0.3,
    patience=2,
    min_lr=1e-6
)

# -------------------------
# TRAIN
# -------------------------

history = model.fit(
    train_gen,
    validation_data=val_gen,
    epochs=15,
    callbacks=[early_stop, lr_reduce]
)

# -------------------------
# EVALUATION
# -------------------------

val_gen.reset()

preds = model.predict(val_gen)
pred_labels = (preds > 0.5).astype(int).reshape(-1)
true_labels = val_gen.classes

accuracy = np.mean(pred_labels == true_labels)
print("\nFinal Accuracy:", accuracy)

# -------------------------
# REPORT
# -------------------------

print(classification_report(true_labels, pred_labels))

# -------------------------
# CONFUSION MATRIX
# -------------------------

cm = confusion_matrix(true_labels, pred_labels)

plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.title("Final MobileNet Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()