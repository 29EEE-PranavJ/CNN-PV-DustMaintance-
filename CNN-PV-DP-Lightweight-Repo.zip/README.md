# CNN-PV-DP
## CNN-Based Solar Panel Dust Prediction System

This project uses Deep Learning and CNN models to detect dust accumulation on solar panels using image-based analysis.

---

## Repository Structure

```bash
CNN-PV-DP/
│
├── src/                     # Source code
│   ├── solar_model.py
│   ├── predict.py
│   ├── compare_models.py
│   ├── cnn_p.py
│   ├── check_verify.py
│   └── final_optimized_mobilenet.py
│
├── models/                  # Trained model weights
│   └── solar_panel_dust_cnn.h5
│
├── sample_images/           # Test images
│
├── docs/                    # Documentation
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## Features
- CNN-based dust classification
- Solar panel image prediction
- Model comparison utilities
- MobileNet optimization
- Trained `.h5` model included

---

## Installation

```bash
git clone <your-repo-link>
cd CNN-PV-DP
pip install -r requirements.txt
```

---

## Run Prediction

```bash
python src/predict.py
```

---

## Model
The trained model is stored in:

```bash
models/solar_panel_dust_cnn.h5
```

---

## Future Improvements
- Real-time IoT integration
- Edge AI deployment
- FPGA acceleration
- Smart solar maintenance analytics

---

## Author
EEE + AI/Embedded Systems Project